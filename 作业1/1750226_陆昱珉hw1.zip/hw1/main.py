import numpy as np
import os
from PIL import Image

def insert_frames(path1, path2, frame_nums, save_path='./processer_img'):
    #read image
    cat = Image.open(path1)
    tiger = Image.open(path2)

    #resize the img to the size of tiger
    cat = cat.resize(tiger.size, Image.ANTIALIAS)

    #convert imgs to arrays in numpy
    tiger = np.array(tiger)
    cat = np.array(cat)

    #create the targer folder if not exists
    if not os.path.exists(save_path):
        os.mkdir(save_path)

    #carry out the algorithm
    for i in range(frame_nums + 1):
        #decide the proportion of cat parts
        a1 = float((frame_nums - i) / frame_nums)
        #decide the proportion of tiger parts
        a2 = float(i / frame_nums)
        #add two parts
        inserted_frame = a1 * cat + a2 * tiger
        #conver the numpy array to the type of uint8
        generated_pic = Image.fromarray(np.uint8(inserted_frame))
        #save the generated pic to the given path
        generated_pic.save(os.path.join(save_path, 'pic_'+str(i)+'.jpg'))

# Press the green button in the gutter to run the script.
if __name__ == '__main__':
    path1 = './img/cat.bmp'
    path2 = './img/tiger.bmp'
    insert_frames(path1=path1, path2=path2, frame_nums=10, save_path='./processer_img')







