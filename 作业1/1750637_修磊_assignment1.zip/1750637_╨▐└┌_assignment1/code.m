close all; 
clear; 
clc; 

A = imread('cat.png')
B = imread('tiger.png')
[height,width]=size(A)


for k=0:100
    t=k/100
    C=uint8(double(A) * (1-t) + double(B) * t)
    b = mod(k,10)
    if b==0
        imshow(C)
    end
end





