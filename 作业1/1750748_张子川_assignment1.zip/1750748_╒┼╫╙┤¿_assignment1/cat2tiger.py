import matplotlib.pyplot as plt # plt 用于显示图片
import matplotlib.image as mpimg # mpimg 用于读取图片
import numpy as np
total=100 #包括首尾在内的图像总数

cat = mpimg.imread('cat.bmp') 
tiger=mpimg.imread('tiger.bmp')
cat=1.0*cat
tiger=1.0*tiger
d=((tiger-cat)/total)/255
current=cat/255

for k in range(0,total):
    plt.imshow(current)
    plt.axis('off') 
    #plt.savefig('./results/frame'+str(k)+'.png')
    plt.ion()
    plt.pause(0.5)
    plt.close()
    current=current+d

    