import cv2
import numpy as np

source = cv2.imread('source.png')
target = cv2.imread('target.png')

height, width, depth = source.shape

frame = int(input('Input frame numbers(including source and target):')) 

for f in range(0, frame):
    t = f / frame
    res = np.round(source * (1.0 - t) + target * t)
    file_name = f'frames/{f}-frame.png'
    cv2.imwrite(file_name, res)

print("images generated in folder frames")