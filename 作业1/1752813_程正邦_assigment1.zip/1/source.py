from PIL import  Image

import numpy as np



imgcat=Image.open(r'C:\Users\cheng\Desktop\20171030173032186.bmp')
imgt=Image.open(r'C:\Users\cheng\Desktop\20171030173126721.bmp')
iimgcat = np.array(imgcat)
iimgt = np.array(imgt)
#iimgcat=mpimg.imread(r'C:\Users\cheng\Desktop\20171030173032186.bmp')
#iimgt=mpimg.imread(r'C:\Users\cheng\Desktop\20171030173126721.bmp')
tc = [ [0] * imgcat.size[0] for i in range(imgcat.size[1])]
for k in range(100):
    imgcat=Image.open(r'C:\Users\cheng\Desktop\20171030173032186.bmp')
    imgt=Image.open(r'C:\Users\cheng\Desktop\20171030173126721.bmp')
    iimgcat = np.array(imgcat)
    iimgt = np.array(imgt)
    t=k/100
    for i in range(imgcat.size[0]):
        for j in range(imgcat.size[1]):
                iimgcat[i,j,:]=(1-t)*iimgcat[i,j,:]+t*iimgt[i,j,:]
    im = Image.fromarray(iimgcat)
    im.save('C:\\Users\\cheng\\Desktop\\1\\'+str(k)+'.png')
print("hello")
