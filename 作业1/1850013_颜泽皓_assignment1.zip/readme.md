# Morphing

## Usage

```cmd
cd ./bin
morph [img path1] [img path2] [Interpation number]
```

The result image will generate with filenames in format  `Interp%d.jpg`.

## Example

![CLI](./img/CLI.jpg)

<img src="./img/Tiger.jpg" style="zoom:25%;" /><img src="./img/Interp0.jpg" style="zoom:25%;" /><img src="./img/Interp1.jpg" style="zoom:25%;" /><img src="./img/Interp2.jpg" style="zoom:25%;" /><img src="./img/Interp4.jpg" style="zoom:25%;" /><img src="./img/cat.jpg" style="zoom:25%;" />

## Pseudocode

The code use **MATRIX OPERATIONS** instead of looping.

```pseudocode
for (i = 0 to n) // n is nInterp
{
    a = (i + 1) / (n + 1); // a is alpha
    D = a * S + (1 - a) * E; // S, E is matrix of mStart and mEnd
    write D;
}
```

## Building Prerequisite

The source file includes the [OpenCV 4.5.1](https://github.com/opencv/opencv/releases/tag/4.5.1) library in the following line. Build it with the library.

```C++
#include <opencv2/imgcodecs.hpp>
```

