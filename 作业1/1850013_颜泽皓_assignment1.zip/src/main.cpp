#include <cstdio>

#include <opencv2/imgcodecs.hpp>

int main(int argc, char *argv[])
{
	float alpha = 0.f;
	cv::Mat mDst;
	std::string strFilename;

	if (argc < 4)
	{
		std::fputs("Wrong Argument Number.\n", stderr);
		std::puts("Useage: morph [img path1] [img path2] [Interpation number]");
		return 1;
	}

	int nInterp = std::atoi(argv[3]);
	if (nInterp <= 0)
	{
		std::fputs("Wrong Interpation Number.", stderr);
		return 1;
	}
	mDst.resize(nInterp);

	// read images
	cv::Mat mStart = cv::imread(argv[1], cv::IMREAD_COLOR);
	cv::Mat mEnd = cv::imread(argv[2], cv::IMREAD_COLOR);
	if (mStart.empty() || mEnd.empty())
	{
		std::fputs("Image open failed.", stderr);
		return 1;
	}

	// morphing
	// 	   this part USE MATRIX OPERATIONS
	// 	   instead of looping.
	// pseudocode:
	// 	   for (i = 0 to n) // n is nInterp
	// 	   {
	// 	       a = (i + 1) / (n + 1); // a is alpha
	// 	       D = a * S + (1 - a) * E; // S, E is matrix of mStart and mEnd
	// 	   	   write D;
	// 	   }
	for (int i = 0; i < nInterp; i++)
	{
		strFilename = "Interp" + std::to_string(i) + ".jpg" ;
		// calculate alpha
		alpha = (i + 1.f) / (nInterp + 1.f);
		// matrix adding
		cv::addWeighted(mStart, alpha, mEnd, 1.f - alpha, 0.0, mDst);
		// write image
		cv::imwrite(strFilename, mDst);
		std::fputs("-Written file: ", stdout);
		std::puts(strFilename.c_str());
	}
	std::puts("Finished.");
	return 0;
}
