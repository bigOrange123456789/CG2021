import matplotlib.pyplot as plt # plt 用于显示图片
import matplotlib.image as mpimg # mpimg 用于读取图片
import numpy as np

cat = mpimg.imread('./image/cat.bmp')
tiger = mpimg.imread('./image/tiger.bmp')

size = tuple(cat.shape)
print(size)

for i in range(1,100):
    w=i/100
    img=(1-w)*cat+w*tiger
    img=img.astype('int')
    if(i%10==0):
        plt.imshow(img)
        plt.axis('off')
        plt.savefig('./image/'+str(i)+'.png')