# Homework1 of Computer Graphics(2020-2021)
# 1850250 Zhao XiMing
# 2020.3.8

import os
import cv2


# img_origin 原始图像
# img_target 目标图像
# interval 图像变形过程产生的中间图像数（不包括origin_img和target_img）
# 图像将输出在"./interval={{interval}}"文件夹中
def img_deform(img_origin, img_target, interval=5):
    # 读取图像
    img1 = cv2.imread(img_origin)
    img2 = cv2.imread(img_target)
    img_ret = cv2.imread(img_origin)

    # 输出路径
    filepath = "interval=" + str(interval) + "/"
    if not os.path.exists(filepath):
        os.mkdir(filepath)

    # 进行图像变形
    sp = img1.shape
    interval = interval + 1
    for k in range(interval + 1):
        for i in range(sp[0]):
            for j in range(sp[1]):
                # 分别处理三个通道
                img_ret[i, j, 0] = (1 - k / interval) * img1[i, j, 0] + (k / interval) * img2[i, j, 0]
                img_ret[i, j, 1] = (1 - k / interval) * img1[i, j, 1] + (k / interval) * img2[i, j, 1]
                img_ret[i, j, 2] = (1 - k / interval) * img1[i, j, 2] + (k / interval) * img2[i, j, 2]
        cv2.imwrite(filepath + str(k) + ".png", img_ret)



interval = 20 # 产生的中间图片数
img_deform("origin.bmp", "target.bmp", interval)
