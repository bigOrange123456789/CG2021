img_cat=imread('C:\Users\Yang\Desktop\猫虎图片\cat.png');
img_tiger=imread('C:\Users\Yang\Desktop\猫虎图片\tiger.png');
frame_video=VideoWriter('C:\Users\Yang\Desktop\猫虎图片\cat_to_tiger.avi');
frame_video.FrameRate=10;
open(frame_video);
for i=1:100
    img_mid=uint8(double(img_cat)*((100-i)/100)+double((img_tiger)*(i/100)));
    writeVideo(frame_video,img_mid);
end
close(frame_video);