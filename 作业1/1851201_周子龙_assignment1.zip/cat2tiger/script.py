import os
import cv2
import numpy as np

catPath = 'cat2tiger/data/cat.png'
tigerPath = 'cat2tiger/data/tiger.png'
outDir = 'cat2tiger/output/'
frameNum = 100

if not os.path.exists(outDir):
    os.mkdir('cat2tiger/output/')

cat = cv2.imread(catPath)
tiger = cv2.imread(tigerPath)

shape = [min(cat.shape[0], tiger.shape[0]), min(cat.shape[1], tiger.shape[1]), min(cat.shape[2], tiger.shape[2])]

for i in range(frameNum):
    interImage = (frameNum - i - 1) / frameNum * cat + i / frameNum * tiger
    cv2.imwrite(f'{outDir}{i + 1}-{frameNum}.png', interImage)
