img_cat=imread('before.png');
img_tiger=imread('after.png');

j = 0;

for i=1:20
    img_mid=uint8(double(img_cat) * (1-j) + double(img_tiger) * j);
    imwrite(img_mid,['frame',num2str(i,'%d'),'.png']);
    j=j + 0.05;
end