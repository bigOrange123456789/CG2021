import cv2
import numpy as np

imgc=cv2.imread("cat.bmp")
imgt=cv2.imread("tiger.bmp")

img = np.array([[[0 for _ in range(3)] for _ in range(184)] for _ in range(184)])

for i in range(11):
    a=i/10
    img=(1-a)*imgc+a*imgt
    cv2.imwrite(str(i)+".bmp",img)


