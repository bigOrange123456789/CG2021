Cat=imread('cat.png');
[Row,Column,Channel]=size(Cat);
figure();
imshow(Cat,[]);
Tiger=imread('tiger.png');
figure();
imshow(Tiger,[]);
Frame=zeros(Row,Column,Channel);
for iFrame=1:10
    percent=(iFrame)/10;
    Frame(:,:,1)=Tiger(:,:,1)*percent+Cat(:,:,1)*(1.0-percent);
    Frame(:,:,2)=Tiger(:,:,2)*percent+Cat(:,:,2)*(1.0-percent);
    Frame(:,:,3)=Tiger(:,:,3)*percent+Cat(:,:,3)*(1.0-percent);
    figure();
    imshow(uint8(Frame));
    imwrite(uint8(Frame),"CatToTiger"+iFrame+".jpg");
end