# -*- coding: utf-8 -*-
# @Time    : 2021/3/7 21:15
# @Author  : STY
# @Email   : 1455670697@qq.com
# @File    : learn.py
# @Software: PyCharm

import numpy as np
import matplotlib.pyplot as plt
import cv2 as cv

img1 = cv.imread('cat.bmp', -1)
img2 = cv.imread('tiger.bmp', -1)

for i in range(101):
    x = i / 100
    img = img1 * x + img2 * (1 - x)
    cv.imwrite(str(i)+'.bmp', img)

cv.waitKey()
