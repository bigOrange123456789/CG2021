clc;clear;
Cat = imread('cat.png');
Tiger = imread('tiger.png');
[m,n]=size(Cat);
TC=zeros(m,n,3);
a=99;
for k=0:a
    t=k/(a+1);
    TC = (1.0-t)*Cat+t*Tiger;
    figure;
    imshow(TC)
end
