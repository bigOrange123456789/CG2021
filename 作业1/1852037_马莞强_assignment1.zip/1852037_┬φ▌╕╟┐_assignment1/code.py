import os
import sys
import numpy as np
from PIL import Image
os.chdir(sys.path[0])

cat = Image.open("./in/cat.bmp")
tiger = Image.open("./in/tiger.bmp")

catArr = np.array(cat)
tigerArr = np.array(tiger)

for i in range(0, 100):
    out = np.full(catArr.shape, 0)
    for j in range(0, catArr.shape[0]):
        for k in range(0, catArr.shape[1]):
            for l in range(0, catArr.shape[2]):
                out[j][k][l] = int(catArr[j][k][l] * (100 - i) / 101 + tigerArr[j][k][l] * (i + 1) / 101)
    outImage = Image.fromarray(np.uint8(out))
    outImage.save("./out/" + str(i) + ".bmp")
