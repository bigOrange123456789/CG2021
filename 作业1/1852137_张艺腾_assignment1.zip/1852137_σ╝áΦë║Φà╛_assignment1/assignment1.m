% read data
catImg = imread('cat.jpg');
tigerImg = imread('tiger.jpg');

% set frame
frame=10;

% operate the function
insertPic(catImg,tigerImg,f);

% insert frames
function insertPic(startImg, endImg, f)
    for k = 0:f
        temp=(f-k)/f*startImg+k/f*endImg;
        imwrite(uint8(temp),"frame_"+k+".jpg");
    end
end


