import cv2
import numpy

cat = cv2.imread("cat.png")
tiger = cv2.imread("tiger.png")

tiger = cv2.resize(tiger, (345, 480), interpolation=cv2.INTER_CUBIC)
cv2.imwrite("tiger.png", tiger)

for k in range(1, 20):
    temp = numpy.empty((480, 345, 3))
    for i in range(0, 480):
        for j in range(0, 345):
            for t in range(0, 3):
                temp[i][j][t] = tiger[i][j][t] * k / 20 + cat[i][j0-k)/20
    cv2.imwrite("process" + str(k) + ".png", temp)
