%% Initialization
cat = imread('img/cat.jpg');
tiger = imread('img/tiger.jpg');
process = VideoWriter('res/process.avi');
%% Morphing process
open(process);
j = 0;
for i = 1:100
    res = uint8(double(cat) * (1 - j) + double(tiger) * j);
    writeVideo(process,res);
    j = j + 0.01;
end
close(process);
%% Writing results
pro = VideoReader('res/process.avi');
k = 1;
while hasFrame(pro)
    temp = readFrame(pro);
    imwrite(temp,strcat('res/P',num2str(k),'.jpg'),'jpg');
    k = k+1;
end

