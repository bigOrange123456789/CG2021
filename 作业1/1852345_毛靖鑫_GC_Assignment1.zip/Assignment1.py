import numpy as np
from PIL import Image
import os
import cv2

def transfer_img(frame=100):
    animal_img_path="./Image/Assignment1"

    cat_img_path=os.path.join(animal_img_path,"cat.jpg")
    tiger_img_path=os.path.join(animal_img_path,"tiger.jpg")
    cat_img=Image.open(cat_img_path)
    tiger_img=Image.open(tiger_img_path)

    cat_w,cat_h=cat_img.size
    tiger_w,tiger_h=tiger_img.size

    w=max(cat_w,tiger_w)
    h=max(cat_h,tiger_h)

    cat_img=cat_img.resize((w,h))
    tiger_img=tiger_img.resize((w,h))

    cat_img=np.asarray(cat_img)
    tiger_img=np.asarray(tiger_img)


    for k in range(0,frame+1):
        t=k/frame
        transfer_img=cat_img*(1-t)+tiger_img*t
        transfer_img=np.clip(transfer_img,0,255)
        transfer_img=Image.fromarray(np .uint8(transfer_img))
        transfer_img.save(os.path.join(animal_img_path,"transfer_1_"+str(k)+".jpg"))

transfer_img()



