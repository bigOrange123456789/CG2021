% The script to get the cat to tiger intermediate frame
% Written by Yuanfeng Li, 2021/3

close all;
clear;
clc;

% 首先读取图片
cat = imread('./sourceimage/cat.jpg');
tiger = imread('./sourceimage/tiger.jpg');

% 将图片进行转化，首先设置中间帧数量
for key = 0:100
    result = double(cat)*(1-key/100) + double(tiger) * key/100;
    % 将double转化为用于显示的uint8形式
    result = uint8(result);
    imwrite(result, ['./resultimage/CatToTiger_',num2str(key),'.jpg']);
end
    


