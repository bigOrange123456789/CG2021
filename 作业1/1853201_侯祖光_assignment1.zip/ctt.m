cat = imread("cat.dib");
tiger = imread("tiger.dib");
% 线性插值 8张
for i = 0:7
    subplot(2,4,i+1);
    imshow(cat*(1-i/7) + tiger*(i/7));
end
    