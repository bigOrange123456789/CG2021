import PIL.Image as Image
import numpy as np
import argparse

def cat2tiger(args):
    #read image
    cat = Image.open('cat.bmp')
    tiger = Image.open('tiger.bmp')

    #convert to numpy
    cat = np.array(cat)/255.
    tiger = np.array(tiger)/255.

    #a list to store all interval image
    frames = []

    for i in range(args.frame_num):
        #cat * (sum_frame - nth_frame)/sum_frame + tiger * nth_frame / sum_frame
        img = cat * (args.frame_num - i) / args.frame_num + tiger * i / args.frame_num
        img = img * 255.
        frames.append(img)

    for idx, img in enumerate(frames):
        img = Image.fromarray(np.uint8(img))
        img.save('./'+str(idx)+'.bmp')

if __name__=='__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument("--frame_num", type=int, default=10, help="The frame between the the start and the final image.")
    args = parser.parse_args()

    cat2tiger(args)