<strong><center>Cat2Tiger</center></strong>

## 1. Intro 

A simple function to convert a cat to a dog gradually. A series of pic in this process is generated and saved according to their sequence.



## 2. Principle

The conversion is a process that makes a little difference for each step and we don't actually have the image in between.



According to the attribution of the problems, a thought of interpolation between time is naturally poped out.



Let's denote:

the pic of the cat as an array $$cat[184,184]$$

the pic of the tiger as an array $$tiger[184,184]$$



We can easily derive the interpolation function:
$$
Image(nth\_frame) = cat * (sum\_frame - nth\_frame) / sum\_frame + tiger * nth\_frame / sum\_frame
$$


## 3. Usage

1. Open up a terminal

2. Get into the cat2tiger.py directory

3. Run " python cat2tiger.py --frame_num 100"

   **ps: frame_num is a variable to decide the interval between the start and the end of the process, which is default to 10**



