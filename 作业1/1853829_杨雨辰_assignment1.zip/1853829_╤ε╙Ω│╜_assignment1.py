import cv2
import numpy as np

img_tiger = cv2.imread("tiger.jpg")    # 读入图像
img_cat = cv2.imread("cat.jpg")
all_state = 10    # 中间状态数，包括变换前后，此处定为10个状态
width = len(img_cat[0])    # 图像的宽度
height = len(img_cat)    # 图像的高度

for t in range(all_state):    # 每个状态
    res_img = np.empty([height, width, 3], dtype=int)    # 叠加后的结果图像
    for i in range(height):    # 每行遍历
        for j in range(width):    # 每列遍历
            for k in range(3):    # 遍历三个颜色通道
                res_img[i][j][k] = int((1 - t / all_state) * img_cat[i][j][k] + (t / all_state) * img_tiger[i][j][k])
    cv2.imwrite("Process{}.jpg".format(t + 1), res_img)    # 保存结果
