function IM=morphing()
Cat=imread('cat.png');
Tiger=imread('tiger.png');
for k=0:99
    t=(k+1)/100;
    TC=uint8((1.0-t)*Cat+t*Tiger);
    filename=['result/TC',num2str(k),'.jpg'];
    imwrite(TC,filename);
end
    
end
