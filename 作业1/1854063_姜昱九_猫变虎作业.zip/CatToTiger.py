import cv2
import numpy as np
import axis

imgCat = cv2.imread('cat.jpg', cv2.IMREAD_UNCHANGED)

width = 255
length = 255

dim = (width, length)
imgCatResized = cv2.resize(imgCat, dim, interpolation=cv2.INTER_AREA)
imgTiger = cv2.imread('tiger.jpg', cv2.IMREAD_UNCHANGED)
imgTigerResized = cv2.resize(imgTiger, dim, interpolation=cv2.INTER_AREA)

for k in range(100):
    per = k / 100
    imgTransfer = np.zeros((255, 255, 3))
    for i in range(255):
        for j in range(255):
            for m in range(3):
                imgTransfer[i][j][m] = (1 - per) * imgCatResized[i][j][m] + per * imgTigerResized[i][j][m]
    imgName = 'transfer/transfer' + str(k) + '.jpg'
    cv2.imwrite(imgName, imgTransfer)
