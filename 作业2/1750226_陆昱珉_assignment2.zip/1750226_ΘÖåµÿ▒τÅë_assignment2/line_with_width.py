# 要添加一个新单元，输入 '# %%'
# 要添加一个新的标记单元，输入 '# %% [markdown]'
# %%
import numpy as np 
import cv2


# %%
canvas = np.zeros((300, 300, 3), dtype="uint8")


# %%
red = (0, 0, 255)
key = 0


# %%
def line_with_width(x0, y0, x1, y1, color, kuan, canvas):
    dx, dy, epsl, i = [0 for i in range(4)]
    x_inc, y_inc, x, y = [0.0 for i in range(4)]
    dx = x1 - x0
    dy = y1 - y0
    x = x0
    y = y0
    if abs(dx) > abs(dy):
        epsl = abs(dx)
    else:
        epsl = abs(dy)
    x_inc = float(dx) / float(epsl)
    y_inc = float(dy) / float(epsl)
 
    for k in range(0, epsl):
        for i in range(0, kuan):
            putpixel(int(x + 0.5 + i / 2), int(y + 0.5), color, canvas)
            putpixel(int(x + 0.5 + i / 2), int(y + 0.5), color, canvas)
        x += x_inc
        y += y_inc


# %%
def putpixel(x, y, color, canvas):
    cv2.circle(canvas, (int(x), int(y)), 1, color, 1)


# %%
line_with_width(0, 0, 200, 230, red, 30, canvas)


# %%
while key != 27:
    cv2.imshow('Canvas', canvas)
    key = cv2.waitKey()
    print(key)


# %%



