def drawLine(x0, y0, x1, y1, w):
    dx = x1-x0
    dy = y1-y0
    w -= 1
    if w % 2 == 0:
        s = -w//2
        l = w//2
    else:
        s = -w//2-1
        l = w//2
    if abs(dx) > abs(dy):
        k = dy/dx
        if dx < 0:
            x0,y0,x1,y1=x1,y1,x0,y0
        y = y0
        for x in range(x0, x1+1):
            y += k
            for d in range(s, l+1):
                ans.append((round(x), round(y+d)))
    else:
        k = dx/dy
        if dy < 0:
            x0,y0,x1,y1=x1,y1,x0,y0
        x = x0
        for y in range(y0, y1+1):
            x += k
            for d in range(s, l+1):
                ans.append((round(x+d), round(y)))


print('Input x0, y0, x1, y1, width. (For example 1 1 100 50 10)')
x0, y0, x1, y1, w = map(int, input().split())
ans = []
drawLine(x0, y0, x1, y1, w)
# print(ans)
str = ';'.join([','.join(map(str, i)) for i in ans])
print(str)
