﻿#include <GL\freeglut.h>
#include <GL\glut.h>
#include <iostream>
#include<math.h>
// writing on a text file
#include <stdio.h>



using namespace std;

//identifier fungsi
void init();
void display(void);
void dda(void);

//  posisi window di layar
int window_x;
int window_y;

//  ukuran window
int window_width = 480;
int window_height = 480;

//  judul window
void main(int argc, char** argv)
{

	
	//  inisialisasi GLUT (OpenGL Utility Toolkit)
	glutInit(&argc, argv);
	// set posisi window supaya berada di tengah 
	window_x = (glutGet(GLUT_SCREEN_WIDTH) - window_width) / 2;
	window_y = (glutGet(GLUT_SCREEN_HEIGHT) - window_height) / 2;
	glutInitWindowSize(window_width, window_height); //set ukuran window 
	glutInitWindowPosition(window_x, window_y); //set posisi window

	glutInitDisplayMode(GLUT_RGBA | GLUT_DOUBLE); // set display RGB dan double buffer
	glutCreateWindow("画有宽度的线");


	init();

	glutDisplayFunc(display); // fungsi display
	glutMainLoop(); // loop pemrosesan GLUT
}

void init()
{
	glClearColor(0.0, 0.0, 0.0, 0.0); //set warna background 
	glColor3f(1.0, 1.0, 1.0); //set warna titik
	glPointSize(1.0); //set ukuran titik
	glMatrixMode(GL_PROJECTION); //set mode matriks yang digunakan 
	glLoadIdentity(); // load matriks identitas
	gluOrtho2D(0.0, 600.0, 0.0, 600.0); // set ukuran viewing window
}
void MidpointLine(int x0, int y0, int x1, int y1)
{
	int widd = 5;
	int wid = widd / 2;
	int a, b, d1, d2, d, x, y;

	a = y0 - y1; b = x1 - x0; d = 2 * a + b;
	d1 = 2 * a; d2 = 2 * (a + b);
	x = x0; y = y0;
	glBegin(GL_POINTS);
	glVertex2i(x, y);
	while (x < x1)
	{
		if (d < 0) { x++; y++; d += d2; }
		else { x++; d += d1; }
		glVertex2i(x, y);
	}  /* while */
	glEnd();
	glFlush();
}
void bresenham(int x1, int y1, int x2, int y2) //iki nokta arasında cizgi cizmemizi saglayan fonksiyon
{
	int x, y, dx, dy, dx1, dy1, px, py, xe, ye, i;
	dx = x2 - x1;
	dy = y2 - y1;
	dx1 = abs(dx);
	dy1 = abs(dy);
	px = 2 * dy1 - dx1; //决策变量初始值（对于m <1，根据x）
	py = 2 * dx1 - dy1; //决策变量初始值（对于m <1，相对于y）
	if (dy1 <= dx1) //如果我的斜率小于1	
	{
		if (dx >= 0) //0-45度之间的条件
		{
			x = x1;
			y = y1;
			xe = x2;
		}
		else //135-180度之间的条件
		{
			x = x2;
			y = y2;
			xe = x1;
		}
		glVertex2i(x, y);
		for (i = 0; x < xe; i++)
		{
			x = x + 1;
			if (px < 0)
			{
				px = px + 2 * dy1; //如果决策变量小于0，则向右上方移动
			}
			else
			{
				if ((dx < 0 && dy < 0) || (dx > 0 && dy > 0))
				{
					y = y + 1; // 向上
				}
				else
				{
					y = y - 1; // 向下
				}
				px = px + 2 * (dy1 - dx1); //计算决策变量的新值
			}
			glVertex2i(x, y);
		}
	}
	else //如果我的斜率大于1
	{
		if (dy >= 0)  // 
		{
			x = x1;
			y = y1;
			ye = y2;
		}
		else //
		{
			x = x2;
			y = y2;
			ye = y1;
		}
		glVertex2i(x, y);
		for (i = 0; y < ye; i++) //
		{
			y = y + 1;
			if (py <= 0)
			{
				py = py + 2 * dx1; //
			}
			else
			{
				if ((dx < 0 && dy < 0) || (dx > 0 && dy > 0))
				{
					x = x + 1; //
				}
				else
				{
					x = x - 1; //
				}
				py = py + 2 * (dx1 - dy1); //
			}
			glVertex2i(x, y);
		}
	}
}

void MidpointLine1(int x0, int y0, int x1, int y1, int width)
{
	int wid = width / 2;
	int a, b, d1, d2, d, x, y;
	float  k = x0 - x1 / y1 - y0 ;
	float deg = atan(k);
	int x3 = cos(deg)*wid;
	int y3 = sin(deg)*wid;


	a = y0 - y1; b = x1 - x0; d = 2 * a + b;
	d1 = 2 * a; d2 = 2 * (a + b);
	x = x0; y = y0;
	glBegin(GL_POINTS);
	glVertex2i(x, y);
	while (x < x1)
	{
		if (d < 0) { x++; y++; d += d2; }
		else { x++; d += d1; }
		bresenham(x, y, x + x3, y + y3);

	}  /* while */
	glEnd();
	glFlush();

}
void display(void)
{
	glClear(GL_COLOR_BUFFER_BIT); //clear color
	MidpointLine1(200,200,400,400,50); //panggil fungsi dda 
	glutSwapBuffers(); //swap buffer 
}

