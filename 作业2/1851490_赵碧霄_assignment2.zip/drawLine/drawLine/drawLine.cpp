﻿// drawLine.cpp : 此文件包含 "main" 函数。程序执行将在此处开始并结束。
//

#include <iostream>
#include <fstream>
using namespace std;

void LineBrush(int x, int y, int width,bool isVertical ,ofstream &outfile)
{
	int midwidth = (width - 1) / 2;
	int lastwidth = width - midwidth - 1;
	if (isVertical)
	{
		for (int k = y - midwidth; k <= y + lastwidth; k++)
			outfile << x << "," << k << ";";
	}
	else
	{
		for (int k = x - midwidth; k <= x + lastwidth; k++)
			outfile << k << "," << y << ";";
	}
	return;
}

void DDA(int x0, int y0, int x1, int y1,int width, ofstream &outfile)
{
	float dx = x1 - x0, dy = y1 - y0;
	float step;
	float x = x0, y = y0;
	bool isVertical;
	if (fabs(dx) > fabs(dy)) {
		step = fabs(dx);
		isVertical = true;
	}
	else {
		step = fabs(dy);
		isVertical = false;
	}
	dx = dx / step;
	dy = dy / step;
	for (int i = 0; i < step; i++)
	{
		//outfile << round(x) << "," << round(y) << ";";
		LineBrush(round(x), round(y), width, isVertical,outfile);
		x += dx;
		y += dy;
	}
	LineBrush(x1, y1, width, isVertical, outfile);
	return;
}

void Middle(int x0, int y0, int x1, int y1,int width, ofstream &outfile)
{
	if (x0 == x1)
	{
		int step;
		if (y0 > y1) step = -1;
		else step = 1;
		for (int i = y0; i != y1; i += step)
			LineBrush(x0, i, width, false, outfile);
	}
	//调整x0和x1的大小位置
	if (x0 > x1)
	{
		int temp = x0;
		x0 = x1;
		x1 = temp;
		temp = y0;
		y0 = y1;
		y1 = temp;
	}
	int a = y0 - y1;
	int b = x1 - x0;
	int d = 2 * a + b;
	int dRightUp = 2 * (a + b);
	int dRight = 2 * a;
	int dRightDown = 2 * (a - b);
	bool isVertical;
	if (abs(a) > abs(b)) isVertical = false;
	else isVertical = true;
	int y = y0;
	if (y0 < y1)
	{
		//向右上方拓展
		for (int x = x0; x <= x1; x++)
		{
			LineBrush(x, y, width, isVertical, outfile);
			if (d > 0) d += dRight;
			else
			{
				d += dRightUp;
				y++;
			}
		}
	}
	else
	{
		//向右下方拓展
		for (int x = x0; x <= x1; x++)
		{
			LineBrush(x, y, width, isVertical, outfile);
			if (d < 0) d += dRight;
			else
			{
				d += dRightDown;
				y--;
			}
		}
	}

	return;
}

int main()
{
	int x0, y0, x1, y1, width;
	ofstream outfile;
	outfile.open("points.txt");
	cout << "请输入直线的起点坐标：" << endl;
	cin >> x0 >> y0;
	cout<<"请输入直线的终点坐标：" << endl;
	cin >> x1 >> y1; 
	cout << "请输入直线的线宽：" << endl;
	cin >> width;
	int No;
	cout << "请选择产生直线的方法：1.DDL 2.中点画线法" << endl;
	cin >> No;
	if (No==1) DDA(x0, y0, x1, y1,width, outfile);
	if (No==2) Middle(x0, y0, x1, y1, width, outfile);
	outfile.close();
}

// 运行程序: Ctrl + F5 或调试 >“开始执行(不调试)”菜单
// 调试程序: F5 或调试 >“开始调试”菜单

// 入门使用技巧: 
//   1. 使用解决方案资源管理器窗口添加/管理文件
//   2. 使用团队资源管理器窗口连接到源代码管理
//   3. 使用输出窗口查看生成输出和其他消息
//   4. 使用错误列表窗口查看错误
//   5. 转到“项目”>“添加新项”以创建新的代码文件，或转到“项目”>“添加现有项”以将现有代码文件添加到项目
//   6. 将来，若要再次打开此项目，请转到“文件”>“打开”>“项目”并选择 .sln 文件
