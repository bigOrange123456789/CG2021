#include <stdio.h>

//输出坐标
void setPixel(int x, int y)
{
    printf("%d,%d;", x, y);
}

//Bresenham画线法，没有浮点计算
void drawline(int x0, int y0, int x1, int y1)
{

    int dx = abs(x1 - x0), sx = x0 < x1 ? 1 : -1;
    int dy = abs(y1 - y0), sy = y0 < y1 ? 1 : -1;
    int err = (dx > dy ? dx : -dy) / 2, e2;

    for (;;)
    {
        setPixel(x0, y0);
        if (x0 == x1 && y0 == y1)
            break;
        e2 = err;
        if (e2 > -dx)
        {
            err -= dy;
            x0 += sx;
        }
        setPixel(x0, y0);
        if (e2 < dy)
        {
            err += dx;
            y0 += sy;
        }
    }
}

//画粗线，同样没有浮点计算
void thickLine(int x0, int y0, int x1, int y1, int d)
{

    int dx = abs(x1 - x0), sx = x0 < x1 ? 1 : -1;
    int dy = abs(y1 - y0), sy = y0 < y1 ? 1 : -1;

    if (dx >= dy)
    {
        for (int i = 0; i < d; i++)
        {
            drawline(x0, y0 + i, x1, y1 + i);
        }
    }
    if (dy > dx)
    {
        for (int i = 0; i < d; i++)
        {
            drawline(x0 + i, y0, x1 + i, y1);
        }
    }
}

//调用
int main()
{
    int d = 10; //线宽
    thickLine(210, 450, 70, 70, d);
}