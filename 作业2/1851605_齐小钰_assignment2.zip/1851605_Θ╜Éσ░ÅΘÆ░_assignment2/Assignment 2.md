# Assignment 2

##### 1851605 齐小钰

## 1. DDA数值微分法

#### 1.1 代码（包括线宽）

```matlab
function flag = DDALine(x0,y0,x1,y1,width)
% 起点(x0,y0)，终点(x1,y1)，线宽width
dx=x1-x0;
dy=y1-y0;
k=dy/dx;   %计算斜率
x=x0;    %初始x值
y=y0;    %初始y值
w=floor(width/2)   %宽度（向上向下各平移了width/2）
for i=x0:x1-1
    x=x+1;
    y=y+k;
    fprintf('%d,%d;',x,y);
    if abs(k)<1
        for j=1:w     %垂直线刷子：直线斜率绝对值小于]时，把刷子置成垂直方向，即将所画直线上的像素点的上下像素点也标出
            fprintf('%d,%d;',x,y+j);
            fprintf('%d,%d;',x,y-j);
        end
    else
        for p=1:w     %平行线刷子：直线斜率绝对值小大于]时，把刷子置成平行方向，即将所画直线上的像素点的左右像素点也标出
            fprintf('%d,%d;',x+p,y);
            fprintf('%d,%d;',x-p,y);
        end
    end    
            
end
flag=0;    %成功返回
end

```

#### 1.2 结果展示

将函数输出的结果输入到助教学长提供的网站中，可得下图

| DDALine(100,100,400,400,1) | ![assignment2 (1)](/Users/qxy2000/courses/ComputerGraphics/HW/HW2/assignment2 (1).png) |
| -------------------------- | ------------------------------------------------------------ |
| DDALine(100,100,400,400,5) | ![assignment2 (2)](/Users/qxy2000/courses/ComputerGraphics/HW/HW2/assignment2 (2).png) |
| DDALine(100,100,200,500,1) | ![assignment2 (3)](/Users/qxy2000/courses/ComputerGraphics/HW/HW2/assignment2 (3).png) |



## 2. 中点画线法法

#### 2.1 代码（包括线宽）

```matlab
function flag = MidpointLine(x0,y0,x1,y1,width)
%UNTITLED 此处显示有关此函数的摘要
% 起点(x0,y0)，终点(x1,y1)，线宽width
a=y0-y1;
b=x1-x0;
x=x0;
y=y0;
w=floor(width/2);   %宽度（向上向下各平移了width/2）
%需要考虑斜率绝对值小于1和大于1的情况，
%因为中点画线法中选取的中点的y值总是上一个y值或上一个y值+1
if -a<=b        %斜率绝对值小于等于1
    d=2*a+b;
    d1=2*a;
    d2=2*(a+b);
    while x<x1     %x值递增
        if d<0      %中点在下方，选择中点上方的像素点
            x=x+1;
            y=y+1;
            d=d+d2;
        else       %中点在上方，选择中点下方的像素点
            x=x+1;
            d=d+d1;
        end
        fprintf('%d,%d;',x,y);
        for j=1:w        %垂直线刷子：直线斜率绝对值小于]时，把刷子置成垂直方向，即将所画直线上的像素点的上下像素点也标出
            fprintf('%d,%d;',x,y+j);
            fprintf('%d,%d;',x,y-j);
        end
        
    end 
else            %斜率绝对值大于1
    d=2*b+a;
    d1=2*b;
    d2=2*(a+b);
    while y<y1   %y值递增
        if d<0    %中点在下方，选择中点左侧的像素点
            y=y+1;
            d=d+d1;
        else     %中点在上方，选择中点右侧的像素点
            x=x+1;
            y=y+1;
            d=d+d2;
        end
        fprintf('%d,%d;',x,y);
        for p=1:w      %平行线刷子：直线斜率绝对值小大于]时，把刷子置成平行方向，即将所画直线上的像素点的左右像素点也标出
            fprintf('%d,%d;',x+p,y);
            fprintf('%d,%d;',x-p,y);
        end
        
    end 
end
flag=0;    %成功返回
end
```

#### 2.2 结果展示

| MidpointLine(100,100,400,400,1); | ![assignment2 (4)](/Users/qxy2000/courses/ComputerGraphics/HW/HW2/assignment2 (4).png) |
| -------------------------------- | ------------------------------------------------------------ |
| MidpointLine(100,100,400,400,5); | ![assignment2 (5)](/Users/qxy2000/courses/ComputerGraphics/HW/HW2/assignment2 (5).png) |
| MidpointLine(100,100,400,200,1); | ![assignment2 (6)](/Users/qxy2000/courses/ComputerGraphics/HW/HW2/assignment2 (6).png) |
| MidpointLine(100,100,200,400,5); | ![assignment2 (7)](/Users/qxy2000/courses/ComputerGraphics/HW/HW2/assignment2 (7).png) |

