def drawPixels(currentx,currenty,n):
    for j in range(0,n+1):
        print(str(currentx)+','+str(currenty+j)+';',end='')

def drawLine(x1,y1,x2,y2,w):
    if x1 > x2:
        x1,x2=x2,x1
        y1,y2=y2,y1
    
    a = y2 - y1
    a2 = a * 2
    b = x2 - x1
    b2 = b * 2
    n = round((a*a+b*b)**0.5/b*w)
    delta1 = a2 + b2
    delta2 = a2
    currentx = x1
    currenty = y1
    d = a2 + b  
    
    isUp=0; # 1-up 0-down
    drawPixels(currentx, currenty, n)
    if d > 0:
        isUp=1
        currentx=currentx+1
        currenty=currenty+1
        drawPixels(currentx, currenty, n)
    else:
        isUp=1
        currentx=currentx+1
        currenty=currenty
        drawPixels(currentx, currenty, n)
    
    for i in range(0,abs(x2-x1)):
        if isUp>0:
            d = d + delta1
        else:
            d = d + delta2
        if d > 0:
            isUp=1
            currentx=currentx+1
            currenty=currenty+1
            drawPixels(currentx, currenty, n)
        else:
            isUp=0
            currentx=currentx+1
            currenty=currenty
            drawPixels(currentx, currenty, n)

x1 = 100
y1 = 120
x2 = 300
y2 = 300
weight = 3

drawLine(x2, y2, x1, y1, weight)
    
        