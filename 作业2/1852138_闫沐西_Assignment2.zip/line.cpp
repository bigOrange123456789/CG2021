#include<iostream>

//define line's width, starting and end at which points

#define LENGTH 3;
#define BEGIN_X 0;
#define BEGIN_Y 499;
#define END_X 300;
#define END_Y 100;

using namespace std;
struct Point
{
    int x;
    int y;
};

void swap(int & i,int & j); //change i and j
void print(Point p, int l); // print some pixels using line's width

int main()
{
    // set points
    int length=LENGTH;
    Point start;
    Point end;
    start.x=BEGIN_X;
    start.y=BEGIN_Y;
    end.x=END_X;
    end.y=END_Y;

    //use to swap some values of the two points based on symmetry
    bool is_reverse=false;
    bool is_negtive=false;
    int neg=start.y+end.y;
    if(end.y<start.y)
    {
        swap(start.y,end.y);
        is_negtive=true;
    }
    else{}
    if(end.y-start.y>end.x-start.x)
    {
        swap(start.x,start.y);
        swap(end.x,end.y);
        is_reverse=true;
    }
    else{}

    //apply middle point algorithm
    Point next=start;
    Point p;
    int dx=end.x-start.x;
    int dy=start.y-end.y;
    int d=dx+2*dy;
    int d1=2*dy;
    int d2=2*dx+2*dy;
    for(int i=start.x;i<end.x;i++)
    {
        p=next;

        if(is_reverse)
        {
            swap(p.x,p.y);
        }
        else{}
        if(is_negtive)
        {
            p.y=neg-p.y;
        }
        else{}

        print(p,length);
        if(d<0)
        {
            next.x++;
            next.y++;
            d+=d2;
        }
        else
        {
            next.x++;
           
            d+=d1;
        }
    }
    print(p,length);
}

void swap(int & i,int & j)
{
    int temp=i;
    i=j;
    j=temp;
}

void print(Point p,int l)
{
    cout<<p.x<<","<<p.y<<";";
    for(int i=0;i<l;i++)
    {
        int flag,increment;
        if(i%2==0)
        {
            flag=-1;
            increment=flag*((i+1)/2+1);
        }
        else
        {
            flag=1;
            increment=flag*(i+1)/2;
        }
        
        if(p.y+increment<500&&p.y+increment>=0)
        {
            cout<<p.x<<","<<p.y+increment<<";";
        }
    }
}