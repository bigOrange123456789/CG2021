#include <iostream>
#include <GL/glut.h>
#include <math.h>

using namespace std;

#define ROUND(a) (int)(a + 0.5)

/* Drawing pixels */

void setPixel(GLint x, GLint y)
{
	glBegin(GL_POINTS);
	glVertex2i(x, y);
	glEnd();
}

void setPixelWidth(int x, int y, int width, int flagWidth)
{
	if (flagWidth == 0)
	{
		while (width >= 1) {
			if (width % 2 == 0)
				setPixel(x, y - width / 2);
			else
				setPixel(x, y + width / 2);
			width--;
		}
	}
	if (flagWidth == 1)
	{
		while (width >= 1) {
			if (width % 2 == 0)
				setPixel(x - width / 2, y);
			else
				setPixel(x + width / 2, y);
			width--;
		}
	}
}

/* DDA algorithm with line width improvement */

void lineDDA(int x0, int y0, int xEnd, int yEnd, int width)
{
	int dx = xEnd - x0, dy = yEnd - y0, steps, k, flagWidth;
	float xIncrement, yIncrement, x = x0, y = y0;
	if (fabs(dx) > fabs(dy)) {
		steps = fabs(dx);
		flagWidth = 0;
	}
	else {
		steps = fabs(dy);
		flagWidth = 1;
	}
	xIncrement = float(dx) / float(steps);
	yIncrement = float(dy) / float(steps);
	setPixelWidth(ROUND(x), ROUND(y), width, flagWidth);
	for (k = 0; k < steps; k++)
	{
		x += xIncrement;
		y += yIncrement;
		if (k % 2 == 0)
			setPixelWidth(ROUND(x), ROUND(y), width, flagWidth);
	}
}

void init(void)
{
	glClearColor(1.0, 1.0, 1.0, 0.0);
	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();
	gluOrtho2D(0.0, 200.0, 0.0, 150.0);
}

void lineDDA(void)
{
	glClear(GL_COLOR_BUFFER_BIT);
	glColor3f(1.0, 0.0, 0.0);
	lineDDA(10, 140, 160, 15, 5);
	glFlush();
}

void main(int argc, char** argv)
{
	glutInit(&argc, argv);
	glutInitDisplayMode(GLUT_SINGLE | GLUT_RGB);
	glutInitWindowPosition(50, 100);
	glutInitWindowSize(400, 300);
	glutCreateWindow("DDA Line Width PLUS");
	init();
	glutDisplayFunc(lineDDA);
	glutMainLoop();
}
