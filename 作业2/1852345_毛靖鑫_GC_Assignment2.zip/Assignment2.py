import math

def drawLightLine(x0,y0,xn,yn):
    point_set=[]
    x0,y0,xn,yn=round(x0),round(y0),round(xn),round(yn)
    #端点起始判断

    if xn-x0==0:#k=∞
        min=y0
        if y0>yn:
            min=yn
        for i in range(0,abs(yn-y0)+1):
            point_set.append([x0,min+i])

    elif yn-y0==0:#k=0
        min=x0
        if x0>xn:
            min=xn
        for i in range(0, abs(xn - x0) + 1):
            point_set.append([min+i, y0])
    else:
        point_set.append([x0, y0])
        if xn-x0<0:
            x0,xn=xn,x0
            y0,yn=yn,y0
        dx,dy=xn-x0,yn-y0
        d=-dx

        x,y=x0,y0
        flag=1
        if dy<0:
            flag=-1
        dy=abs(dy)
        if dy<=dx:
            for i in range(0,dx,1):
                d+=2*dy
                x+=1
                if d>=0:
                    y+=flag
                    d -= 2 * dx
                    point_set.append([x,y])
                else:
                    point_set.append([x,y])
        else:
            for i in range(0,dy,1):
                d+=2*dx
                y+=flag
                if d>=0:
                    x+=1
                    d -= 2 * dy
                    point_set.append([x,y])
                else:
                    point_set.append([x,y])

    text=""
    for point in point_set:
        text+=str(point[0])+","+str(point[1])+";"

    return point_set,text

def drawLine_way1(x0, y0, xn, yn, width=1,style="ac"):
    x0, y0, xn, yn = round(x0), round(y0), round(xn), round(yn)

    if width==1 and (xn==x0 or yn==y0):
        res,text=drawLightLine(x0,y0,xn,yn)
        return res,text

    if xn - x0 < 0:
        x0, xn = xn, x0
        y0, yn = yn, y0
    dx, dy = xn - x0, yn - y0
    k = dy / (dx + 1e-10)
    # 计算长方形四点(OO'为中轴线)其中，O(x0,y0),O'(xn,yn)
    #   a----------b
    #   |          |
    #   O          O'
    #   |          |
    #   c----------d
    xa, ya = x0 - (k * width) / (2 * math.sqrt(1 + k * k)), y0 + (width) / (2 * math.sqrt(1 + k * k))
    xb, yb = xa + dx, ya + dy
    xc, yc = 2 * x0 - xa, 2 * y0 - ya
    xd, yd = xc + dx, yc + dy

    one_edge, _ = drawLightLine(xa, ya, xb, yb)
    another_edge, _ = drawLightLine(xc, yc, xd, yd)

    # 以下两种方法仅方向不同：

    # 将ac刷满空间
    if style=="ac":
        point_set = []
        for i in range(0, len(one_edge)):
            now_set, _ = drawLightLine(one_edge[i][0], one_edge[i][1], another_edge[i][0], another_edge[i][1])
            another_set,_ = drawLightLine(one_edge[i][0], one_edge[i][1] - 1, another_edge[i][0], another_edge[i][1] - 1)
            point_set += now_set
            point_set += another_set
    # '''

    # 将ab刷满空间
    #'''
    if style=="ab":
        point_set = []
        endpoint_set,_=drawLightLine(xa,ya,xc,yc)
        for point in endpoint_set:
            now_set,_=drawLightLine(point[0],point[1],point[0]+dx,point[1]+dy)
            another_set,_= drawLightLine(point[0], point[1]-1, point[0] + dx, point[1] + dy-1)
            point_set+=now_set
            point_set+=another_set
    #'''
    text = ""
    for point in point_set:
        text += str(point[0]) + "," + str(point[1]) + ";"

    return point_set, text

def drawLine_way2(x0,y0,xn,yn,width=1):
    x0, y0, xn, yn = round(x0), round(y0), round(xn), round(yn)

    if width==1 and (xn==x0 or yn==y0):
        res,text=drawLightLine(x0,y0,xn,yn)
        return res,text

    if xn-x0<0:
        x0,xn=xn,x0
        y0,yn=yn,y0
    dx, dy = xn - x0, yn - y0
    k=dy/(dx+1e-10)
    #计算长方形四点(OO'为中轴线)其中，O(x0,y0),O'(xn,yn)
    #   a----------b
    #   |          |
    #   O          O'
    #   |          |
    #   c----------d
    xa,ya=x0-(k*width)/(2*math.sqrt(1+k*k)),y0+(width)/(2*math.sqrt(1+k*k))
    xb,yb=xa+dx,ya+dy
    xc,yc=2*x0-xa,2*y0-ya
    xd,yd=xc+dx,yc+dy

    one_edge=[]
    another_edge=[]

    #绘制长方形四边，确定边界
    ab_edge,_=drawLightLine(xa,ya,xb,yb)
    cd_edge, _ = drawLightLine(xc, yc, xd, yd)

    if k>0:
        # 根据k正负确定关键边界的方向
        bd_edge, _ = drawLightLine(xb, yb, xd, yd)
        ac_edge, _ = drawLightLine(xa, ya, xc, yc)

        #a->b->d
        one_edge+=ab_edge[:-1]#去除重复交点
        one_edge+=bd_edge
        #a->c->d
        another_edge+=ac_edge[:-1]#去除重复交点
        another_edge+=cd_edge
    else:
        # 根据k正负确定关键边界的方向
        ca_edge, _ = drawLightLine(xc, yc, xa, ya)
        db_edge, _ = drawLightLine(xd, yd, xb, yb)

        #c->a->b
        one_edge += ca_edge[:-1]#去除重复交点
        one_edge += ab_edge
        #c->d->b
        another_edge += cd_edge[:-1]#去除重复交点
        another_edge += db_edge

    index=0
    true_one_edge=[]
    true_another_edge=[]
    #'''
    #取最后一个点(效果最好)
    for i in range(0,len(one_edge)):
        if len(true_one_edge)==0:
            true_one_edge.append(one_edge[i])
            index+=1
        elif one_edge[i][0]==one_edge[i-1][0]:
            true_one_edge[index-1][1]=one_edge[i][1]
        else:
            true_one_edge.append(one_edge[i])
            index+=1
    index=0
    for i in range(0,len(another_edge)):
        if len(true_another_edge)==0:
            true_another_edge.append(another_edge[i])
            index+=1
        elif another_edge[i][0]==another_edge[i-1][0]:
            true_another_edge[index-1][1]=another_edge[i][1]
        else:
            true_another_edge.append(another_edge[i])
            index+=1
    #'''

    '''
    #取第一个点
    for i in range(0, len(one_edge)):
        if len(true_one_edge) == 0:
            true_one_edge.append(one_edge[i])
            index += 1
        elif one_edge[i][0] == one_edge[i - 1][0]:
            continue
        else:
            true_one_edge.append(one_edge[i])
            index += 1
    index = 0
    for i in range(0, len(another_edge)):
        if len(true_another_edge) == 0:
            true_another_edge.append(another_edge[i])
            index += 1
        elif another_edge[i][0] == another_edge[i - 1][0]:
            continue
        else:
            true_another_edge.append(another_edge[i])
            index += 1
    '''

    #'''
    #对重复点滤除操作
    point_set=[]
    for i in range(0,len(true_one_edge)):#必有true_one_edge[i][0]==true_another_edge[i][0]
        now_set, _ = drawLightLine(true_one_edge[i][0], true_one_edge[i][1], true_another_edge[i][0], true_another_edge[i][1])
        point_set+=now_set
    #'''

    '''
    #不去除重复点
    point_set=[]
    for i in range(0,len(one_edge)):#必有one_edge[i][0]==another_edge[i][0]
        now_set, _ = drawLightLine(one_edge[i][0], one_edge[i][1], another_edge[i][0], another_edge[i][1])
        point_set+=now_set
    '''

    text = ""
    for point in point_set:
        text += str(point[0]) + "," + str(point[1]) + ";"

    return point_set,text

if __name__=="__main__":
    width=2

    point=[250,250]

    dir=[[100,100],[100,-100],[50,100],[50,-100],[100,50],[100,-50],[0,100],[0,-100],[100,0],[-100,0],[-50,100],[-50,-100],[-100,50],[-100,-50],[-100,100],[-100,-100]]

    f1=open("test1.txt","w+")
    f2=open("test2.txt","w+")

    for i in range(len(dir)):

        x=point[0]+dir[i][0]
        y=point[1]+dir[i][1]

        _, text1 = drawLine_way1(point[0], point[1], x, y, width)
        _, text2 = drawLine_way2(point[0], point[1], x, y, width)

        f1.write(text1)
        f1.write('\n')
        f2.write(text2)
        f2.write('\n')

    f1.close()
    f2.close()



