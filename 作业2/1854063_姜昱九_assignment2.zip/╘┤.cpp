#include <iostream>
#include <fstream>

using namespace std;

// Bresenham算法


void drawLine(int x0, int y0, int x1, int y1) {
    ofstream out("outputPixel.txt");
    int dx = abs(x1 - x0), sx = x0 < x1 ? 1 : -1;
    int dy = abs(y1 - y0), sy = y0 < y1 ? 1 : -1;
    int err = (dx > dy ? dx : -dy) / 2, e2;

    while (true) 
    {
        out << x0 << "," << y0 << ";";
        if (x0 == x1 && y0 == y1) break;
        e2 = err;
        if (e2 > -dx) { err -= dy; x0 += sx; }
        if (e2 < dy) { err += dx; y0 += sy; }
    }
}

//画粗线
void drawThickLine(int x0, int y0, int x1, int y1, int d)
{
    int dx = abs(x1 - x0), sx = x0 < x1 ? 1 : -1;
    int dy = abs(y1 - y0), sy = y0 < y1 ? 1 : -1;
    if (dx >= dy)
    {
        for (int i = 0; i < d; i++)
        {
            drawLine(x0 + i, y0, x1, y1);
        }
    }
    else
    {
        for (int i = 0; i < d; i++)
        {
            drawLine(x0 , y0 + i, x1, y1);
        }
    }
}
//此处有较大问题，绞尽脑汁没有得出如何既满足按照斜率斜向偏移，又满足没有浮点数运算的方法

int main()
{
    ifstream in("sampleInput.txt");
    cout << "First input the x0,y0,x1,y1, which is the coordinate of the start point and the end point of the line:" << endl;
	int x0, y0, x1, y1;
	in >> x0 >> y0 >> x1 >> y1;
    cout << "\nThen input the width of the line:" << endl;
    int d;
    in >> d;
    drawThickLine(x0, y0, x1, y1, d);
}